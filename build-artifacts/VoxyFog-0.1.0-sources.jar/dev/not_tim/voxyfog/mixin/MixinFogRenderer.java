package dev.not_tim.voxyfog.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.not_tim.voxyfog.VoxyCompat;
import dev.not_tim.voxyfog.VoxyFogTuning;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_758.class, priority = 900)
public abstract class MixinFogRenderer {
    @Inject(
            method = "setupFog",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/systems/RenderSystem;getDevice()Lcom/mojang/blaze3d/systems/GpuDevice;",
                    remap = false
            )
    )
    private void voxyfog$applyVoxyDistanceFog(
            class_4184 camera,
            int renderDistance,
            class_9779 deltaTracker,
            float partialTick,
            class_638 level,
            CallbackInfoReturnable<Vector4f> cir,
            @Local(type = class_7285.class) class_7285 fogData
    ) {
        VoxyCompat.State state = VoxyCompat.getState();
        if (!state.isActive()) {
            return;
        }

        if (fogData.field_60584 < 16.0f) {
            return;
        }

        float vanillaDistanceBlocks = class_310.method_1551().field_1773.method_3193();
        VoxyFogTuning.FogRange fogRange = VoxyFogTuning.compute(state.renderDistanceBlocks(), vanillaDistanceBlocks);
        if (fogRange == null) {
            return;
        }

        fogData.field_60582 = Math.min(fogData.field_60582, fogRange.start());
        fogData.field_60584 = Math.min(fogData.field_60584, fogRange.end());
    }
}
