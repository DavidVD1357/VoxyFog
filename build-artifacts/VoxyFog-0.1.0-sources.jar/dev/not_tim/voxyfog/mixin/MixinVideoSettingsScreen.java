package dev.not_tim.voxyfog.mixin;

import dev.not_tim.voxyfog.VoxyFogConfig;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_446;
import net.minecraft.class_4667;
import net.minecraft.class_5676;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_446.class)
public abstract class MixinVideoSettingsScreen extends class_4667 {
    protected MixinVideoSettingsScreen(class_437 lastScreen, class_315 options, class_2561 title) {
        super(lastScreen, options, title);
    }

    @Inject(method = "addOptions", at = @At("TAIL"))
    private void voxyfog$addToggle(CallbackInfo ci) {
        this.method_37063(
                class_5676.method_32614(VoxyFogConfig.isEnabled())
                        .method_32617(
                                this.field_22789 / 2 - 155,
                                this.field_22790 - 74,
                                150,
                                20,
                                class_2561.method_43471("voxy_renderdistance_fog.option.enabled"),
                                (button, value) -> VoxyFogConfig.setEnabled(value)
                        )
        );
    }
}
